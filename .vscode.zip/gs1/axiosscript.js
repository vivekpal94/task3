document.getElementById("btn").addEventListener("click", makerequest);

// function makerequest()
// {
// console.log("Button Clicked");
// config = {
//     method: 'get',
//     url:'data.txt'
// }
// const promiseObj = axios(config)
// promiseObj.then((res)=>{
// console.log(res.data)
// })
// }

// function makerequest()
// {
// console.log("Button Clicked");
// config = {
//     method: 'get',
//     url:'data.txt'
// }
// axios(config) .then((res)=>{  
// console.log(res.data)
// })
// }

// function makerequest() {
//     console.log("Button Clicked")
//     axios.get('data.txts').then((res)=> {
//  console.log(res)
//  console.log(res.data)
//     })
// }

// function makerequest() {
//     console.log("Button Clicked")
//     axios('data.txt').then((res)=> {
//  console.log(res)
//  console.log(res.data)
//     })
// }

///////////////////////////
/// Promise then  |Error Handling
// function makerequest() {
//         console.log("Button Clicked")
//         /////// here i have given wrong file name data1
//         axios.get('data1.txt').then((res)=> {
//      console.log(res)
//      console.log(res.data)
//         }).catch((error)=>{
//             console.log(error)
//         })
//     }
 
// Promise then | Showing Data in Browser
// function makerequest() {
//     console.log("Button Clicked")
//     /////// here i have given wrong file name data1
//     axios.get('data.json').then((res)=> {
//  console.log(res)
//  console.log(res.data)
//  document.getElementById("divdata").innerText=res.data;
//     }).catch((error)=>{
//         console.log(error)
//     })
// }

// Async and Await
// async function makerequest()
// {
//     console.log("Button Clicked")
//     config = {
//         method:'get',
//         url: 'data.txt'
//     } 
//     const res = await axios(config)
//     console.log(res)
//     console.log(res.data)
// }

// async function makerequest()
// {
//     console.log("Button Clicked")
//     const res = await axios.get('data.txt')
//     console.log(res)
//     console.log(res.data)
// }

// Asyn and Await Error handling
// Important
// async function makerequest()
// {
//     alert("hii");
//    try{
//     console.log("Button Clicked")
//     const res = await axios.get('data.json')
//     console.log(res)
//     console.log(res.data)
//    }
// //jab file ka url correct nhi hota hai tab catch method run hoti hai
//    catch(error)
//    {
//        console.log("here is file not found")
      
//    }
// }
//Async and Await | Showing data in Browser
async function makerequest()
{
    alert("hello");
   try{
    console.log("Button Clicked")
    const res = await axios.get('data.json')
    console.log(res)
    console.log(res.data)
    document.getElementById("divdata").innerText=res.data.name;
    document.getElementById("divdata1").innerText=res.data.age;
   }
   catch(error)
   {
       console.log("here is file not found")
   }
}
